package Assistedlesson2;

public class Constructors {
	
		  private String name;
		  Constructors() {
		    System.out.println("Constructor Called:");
		    name = "Simplilearn";
		   
		  }
		  public static void main(String[] args) {
		   Constructors object = new Constructors();
		    System.out.println("The name is " + object.name);
		    
		  }
		}


