package Assistedlesson2;

public class Methods {

		  public int addNumbers(int x, int y) {
		    int sum = x + y;
		    return sum;
		  }
		  public static void main(String[] args) {
		    int no1 = 60;
		    int no2 = 35;
		    Methods obj = new Methods();
		    int result = obj.addNumbers(no1, no2);
		    System.out.println("Sum is: " + result);
		  }
		}


