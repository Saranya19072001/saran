package Assistedlesson2;

public class Strings {
	public static void StrConcat(String str1) 
			    { 
			        str1 = str1 + "Java"; 
			    } 
			   
			    public static void StrBufConcat(StringBuffer str2) 
			    { 
			        str2.append("Java"); 
			    } 
			   
			    public static void StrBuildConcat(StringBuilder str3) 
			    { 
			        str3.append("Java"); 
			    } 
			   
			    public static void main(String[] args) 
			    { 
			        String str1 = "Welcome"; 
			        StrConcat(str1); 
			        System.out.println("The final String is - " + str1); 
			   
			        StringBuffer str2 = new StringBuffer("Welcome"); 
			        StrBufConcat(str2); 
			        System.out.println("The final String is - " + str2); 
			   
			        StringBuilder str3 = new StringBuilder("Welcome"); 
			        StrBuildConcat(str3);
			        System.out.println("The final String is -" + str3); 
			    } 
			}


