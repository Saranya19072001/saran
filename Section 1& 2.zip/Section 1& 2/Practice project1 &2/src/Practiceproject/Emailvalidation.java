package Practiceproject;
import java.util.Scanner;
import java.util.ArrayList;
public class Emailvalidation {
	
		public static void main(String[] args) {
			Scanner input = new Scanner(System.in);
			ArrayList<String> mail = new ArrayList<String>();
			mail.add("jeevi@gmail.com");
			mail.add("rani@gmail.com");
			mail.add("dhaya@gmail.com");
			mail.add("bhuvi@gmail.com");
			mail.add("gokul@gmail.com");
			System.out.println("ENTER USER EMAIL ID:");
			String userId = input.nextLine();
			//checks user mail id and shows found or not
				if (mail.contains(userId)) {
					System.out.println();
					System.out.println("Email ID " + userId + " found");
				} 
				else {
					System.out.println("Email ID " + userId + " Not found");

				}
			}
		}


