package Assistedlesson3;

public class Mythreadextends {
		
		 	public void run()
		 	{
		  		System.out.println("concurrent thread started running..");
		}
		 	public static void main( String args[] )
		 	{
		  		Mythreadextends mt = new  Mythreadextends();
		  		mt.start();
		 	}
			private void start() {
				// TODO Auto-generated method stub
				System.out.println("thread loading...");
			}
		}

	